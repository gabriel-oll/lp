-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22-Maio-2022 às 03:57
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `lp-cms`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem`
--

CREATE TABLE `imagem` (
  `id` int(11) NOT NULL,
  `img-1` varchar(255) CHARACTER SET utf8 NOT NULL,
  `img-2` varchar(255) CHARACTER SET utf8 NOT NULL,
  `img-3` varchar(255) CHARACTER SET utf8 NOT NULL,
  `img-4` varchar(255) CHARACTER SET utf8 NOT NULL,
  `img-5` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `imagem`
--

INSERT INTO `imagem` (`id`, `img-1`, `img-2`, `img-3`, `img-4`, `img-5`) VALUES
(1, '../assets/img/uploadsbg 4.jpg', '../assets/img/uploadsbg 2.jpg', '../assets/img/uploadsbg 1.jpg', '../assets/img/uploadsbg 3.jpg', 'null'),
(2, '../assets/img/uploadsaboutus-example.jpg', '', '', '', ''),
(3, '', '', '', '', ''),
(4, '../assets/img/uploadsoriginal-6a3f3a4d0bae167bf98fc296f9fb0c56 1.png', '../assets/img/uploads070f89b0c7c7a0e0eca773a5cc7471e9 1.jpg', '../assets/img/uploadsoriginal-5f523235b5365bacbd757be95b192749 1.jpg', '../assets/img/uploads3a537c3447e66536b4098b341ccff15a 1.png', 'null');

-- --------------------------------------------------------

--
-- Estrutura da tabela `texto`
--

CREATE TABLE `texto` (
  `id` int(11) NOT NULL,
  `main-title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `sub-title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `inner-text` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `texto`
--

INSERT INTO `texto` (`id`, `main-title`, `sub-title`, `inner-text`) VALUES
(1, 'Title', 'Sub-title', ''),
(2, 'Title two', 'Sub-title two', 'Inner-text three'),
(3, 'Title three', 'Sub-title three', ''),
(4, 'Title four', 'Sub-title four', 'Inner text four');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `imagem`
--
ALTER TABLE `imagem`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `texto`
--
ALTER TABLE `texto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `imagem`
--
ALTER TABLE `imagem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `texto`
--
ALTER TABLE `texto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
